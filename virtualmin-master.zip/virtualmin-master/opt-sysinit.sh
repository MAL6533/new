#!/bin/bash
service apache2 start
/usr/bin/systemctl --init default